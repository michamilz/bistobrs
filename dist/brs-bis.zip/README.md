# BIS zu BRS und zurück

Browsererweiterung für Chrome

Wechseln Sie direkt zwischen der Darstellung den Sitzungen und Vorgängen auf 
https://bis.schwerin.de und https://brs-schwerin.de.

Betrachten Sie endlich auf https://bis.schwerin.de alle PDFs auch im Browser, 
anstatt sie jedesmal herunterzuladen.

Link zum Chrome Web Store folgt.
